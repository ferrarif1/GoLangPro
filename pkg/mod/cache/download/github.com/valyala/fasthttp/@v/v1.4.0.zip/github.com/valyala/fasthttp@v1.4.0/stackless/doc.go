// Package stackless provides functionality that may save stack space
// for high number of concurrently running goroutines.
package stackless
