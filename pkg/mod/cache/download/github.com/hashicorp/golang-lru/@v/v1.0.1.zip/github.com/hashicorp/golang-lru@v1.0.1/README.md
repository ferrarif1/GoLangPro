golang-lru
==========

Please use `github.com/hashicorp/golang-lru/v2` for all new code as this
version supports generics and is faster; old code can specify a specific tag,
e.g.  `github.com/hashicorp/golang-lru/v0.6.0` for backwards compatibility.
