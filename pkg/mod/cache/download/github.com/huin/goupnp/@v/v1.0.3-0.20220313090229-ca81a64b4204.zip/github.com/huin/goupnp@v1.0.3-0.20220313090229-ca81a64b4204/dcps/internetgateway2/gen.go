//go:generate goupnpdcpgen -dcp_name internetgateway2
package internetgateway2
