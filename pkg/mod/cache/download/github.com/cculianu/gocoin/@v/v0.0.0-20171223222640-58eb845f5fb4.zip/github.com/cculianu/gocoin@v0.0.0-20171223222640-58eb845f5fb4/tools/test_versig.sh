go run versigmsg.go mkFqgr8VTRybS4sfpsn8pUfNgAnFXcvaPx "IP/sMWQB7mrwvYI4QYFE4isjh+2V/+MtlsOXCXYpCPOxGCso/i9yQgAxEO+rrJWGvRFjpckQ4DFWYsBE+EgSb60=" Hello
