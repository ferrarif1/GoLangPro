These test vectors come from the satoshi client.
https://github.com/bitcoin/bitcoin/tree/master/src/test/data
